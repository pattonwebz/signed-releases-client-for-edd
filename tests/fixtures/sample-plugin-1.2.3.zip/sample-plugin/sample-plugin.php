<?php
/**
 * Plugin Name: Sample Plugin
 * Version: 1.2.3
 */
